const fileSystem = [
    {
        value: 'All Database',
        label: 'All Database',
        children: []
    },
    {
        value: 'Default Database',
        label: 'Default Database',
        children: []
    },
    {
        value: 'dev_jrnydb',
        label: 'dev_jrnydb',
        children: [
            {
                value: 'All Schemas',
                label: 'All Schemas'
            },
            {
                value: 'Default Schema',
                label: 'Default Schema',
            },
            {
                value: 'pg_catalog',
                label: 'pg_catalog',
            },
            {
                value: 'public',
                label: 'public',
            },
        ]
    },
    {
        value: 'dev_jrnydb_0313',
        label: 'dev_jrnydb_0313',
        children: []
    },
    {
        value: 'jrnydb',
        label: 'jrnydb',
        children: []
    },
    {
        value: 'postgres',
        label: 'postgres',
        children: []
    },
];
const empires = [
    {
        value: 'favorite-empires',
        label: 'Favorite Empires',
        children: [
            {
                value: 'classical-era',
                label: 'Classical Era',
                children: [
                    {
                        value: 'persian',
                        label: 'First Persian Empire',
                    },
                    {
                        value: 'qin',
                        label: 'Qin Dynasty',
                    },
                    {
                        value: 'spqr',
                        label: 'Roman Empire',
                    },
                ],
            },
            {
                value: 'medieval-era',
                label: 'Medieval Era',
                children: [
                    {
                        value: 'abbasid',
                        label: 'Abbasid Caliphate',
                    },
                    {
                        value: 'byzantine',
                        label: 'Byzantine Empire',
                    },
                    {
                        value: 'holy-roman',
                        label: 'Holy Roman Empire',
                    },
                    {
                        value: 'ming',
                        label: 'Ming Dynasty',
                    },
                    {
                        value: 'mongol',
                        label: 'Mongol Empire',
                    },
                ],
            },
            {
                value: 'modern-era',
                label: 'Modern Era',
                children: [
                    {
                        value: 'aztec',
                        label: 'Aztec Empire',
                    },
                    {
                        value: 'british',
                        label: 'British Empire',
                    },
                    {
                        value: 'inca',
                        label: 'Inca Empire',
                    },
                    {
                        value: 'qing',
                        label: 'Qing Dynasty',
                    },
                    {
                        value: 'russian',
                        label: 'Russian Empire',
                    },
                    {
                        value: 'spanish',
                        label: 'Spanish Empire',
                    },
                ],
            },
        ],
    },
];

export {
    fileSystem,
    empires,
};