import { useState } from 'react'
import './Analysis.css'
import AnalysisCheckBox from './AnalysisCheckBox/AnalysisCheckbox'

const Analysis = (props) => {
  const n = 18
  const [greenCheckboxShow, setGreenCheckboxShow] = useState('')
  const [redCheckboxShow, setRedCheckboxShow] = useState('')

  const redCheckboxHandler = (e) =>{
    if(e.target.checked){
      setGreenCheckboxShow('')
      setRedCheckboxShow('redChk')
    }else{
      setGreenCheckboxShow('')
      setRedCheckboxShow('')
    }
  }

  const greenCheckboxHandler = (e) =>{
    if(e.target.checked){
      setGreenCheckboxShow('greenChk')
      setRedCheckboxShow('')
    }else{
      setGreenCheckboxShow('')
      setRedCheckboxShow('')
    }
  }

  const redGreenCheckboxHandler = (e) => {
    if(e.target.checked){
      setGreenCheckboxShow('')
      setRedCheckboxShow('')
    }
  }
    return(
        <>  
        <div className="db-breadcrumb">postgres@196.263.180.216 \  dev_jrnydb_0313   \  information_schema \  pg_catalog \  public \ PostgreSQL</div>           
         <div className="analysis-filter d-flex">
              <p className="me-2 mb-0">Filter by</p>
              <div>
                <div className="custom-check form-check">
                    <input className="form-check-input me-1" type="radio" onChange={greenCheckboxHandler} name='green-red-chk' value='green' id="flexCheckDefault-green-chk" disabled={props.fltChkDisabled}/>
                </div>
                <div className="custom-check form-check">
                    <input className="form-check-input me-1" type="radio" onChange={redCheckboxHandler} name='green-red-chk' value='red' id="flexCheckDefault-red-chk" disabled={props.fltChkDisabled}/>
                </div>
                <div className="custom-check form-check">
                    <input className="form-check-input me-1" type="radio" onChange={redGreenCheckboxHandler} name='green-red-chk' value='both' id="flexCheckDefault-green-red-chk" disabled={props.fltChkDisabled}/>
                </div>
              </div>
             

            </div>
            <h2 className="mt-4">Table Name 01</h2>
        
            <div className="row g-1">
                {
                  [...Array(n)].map((e, i) => <AnalysisCheckBox keyProp={i} name={i} value= "Column 33" greenChkClass={greenCheckboxShow} redChkClass={redCheckboxShow} fltChkDisabled={props.fltChkDisabled}/> )
                }
            </div>

            <h2 className="mt-5">Table Name 02</h2>
    
            <div className="row g-1">
                {
                  [...Array(n)].map((e, i) => <AnalysisCheckBox keyProp={i} name={i} value= "Column 33" greenChkClass={greenCheckboxShow} redChkClass={redCheckboxShow} fltChkDisabled={props.fltChkDisabled}/>)
                }
            </div>
            <h2 className="mt-5">Table Name 03</h2>
        
            <div className="row g-1">
                {
                  [...Array(n)].map((e, i) => <AnalysisCheckBox keyProp={i} name={i} value= "Column 33" greenChkClass={greenCheckboxShow} redChkClass={redCheckboxShow} fltChkDisabled={props.fltChkDisabled}/>)
                }
            </div>
           
        </>
    )
}

export default Analysis