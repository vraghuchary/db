import { useState } from 'react';
import CustomCheckbox from '../../CustomCheckbox/CustomCheckbox'
import TooltipBts from '../../Tooltip/Tooltip'

const AnalysisCheckBox = (props) => {
    const [childData, setChildData] = useState('unchecked');

  // Function to receive data from the child component
  const receiveDataFromChild = (data) => {
    // Update parent component's state with the received data
    setChildData(data);
  };
    return(
        <>
            <div className={"col-2 " + childData + " " + props.greenChkClass +" "+props.redChkClass} key={props.keyProp}>
                <div className="d-flex justify-content-between align-items-center p-1 ps-3 border bg-light" key={props.keyProp}><CustomCheckbox name={props.name} value={props.value} sendDataToParent={receiveDataFromChild} fltChkDisabled={props.fltChkDisabled}/> <TooltipBts fltChkDisabled={props.fltChkDisabled}/></div>
            </div>
        </>
    )
}

export default AnalysisCheckBox