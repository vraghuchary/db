import { useState } from "react";
// import { GoFileSymlinkDirectory, GoFileSymlinkFile } from "react-icons/go";
const Folder = ({ explorer }) => {
  const [expand, setExpand] = useState(false);
  if (explorer.items) {
    return (
      <div>
        {/* <GoFileSymlinkDirectory /> */}
        { expand ? <span>&#129175;</span> : <span>&#129174;</span> }
        <span
          style={{
            cursor: "pointer",
            paddingLeft: "5px"
          }}
          onClick={() => setExpand(!expand)}
        >
          {explorer.name}
          <br />
        </span>
        <div
          style={{
            display: expand ? "block" : "none",
            paddingLeft: "15px",
            cursor: "pointer"
          }}
        >
          {" "}
          {explorer.items.map((exp, idx) => {
            return (
              <>
                <Folder key={idx} explorer={exp} />
              </>
            );
          })}
        </div>
      </div>
    );
  } else {
    return (
      <div
        style={{
          cursor: "default",
          paddingLeft: "5px"
        }}
      >
        {/* <GoFileSymlinkFile /> */}
        <span>&#126982;</span>
        {explorer.name}
        <br />
      </div>
    );
  }
};

export default Folder;
