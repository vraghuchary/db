import React from 'react'
import logo from '../assets/images/logo.png';
import './Header.css'
import DarkMode from '../DarkMode/DarkMode';
import { useNavigate  } from 'react-router-dom'
import {useMyContext} from '../Main/Main'
import 'bootstrap-icons/font/bootstrap-icons.css';

function Header() {
  const history = useNavigate ();
  const { value, updateValue } = useMyContext();

  const logOutHandler = () => {
    history('/')
  }

  const navigateToDashboard = () =>{
    updateValue('dashboardAnalysis');
  }

  return (
    <header className="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3">
      <div className="col-md-1 mb-2 mb-md-0">
        <img src = {logo} alt='database' className="logo"/>
      </div>
      <div className="col-md-1 mb-2 mb-md-0">
        <button className="btn btn-light d-flex pe2" onClick={navigateToDashboard}><i className="bi bi-columns-gap pe-2"></i>
 DashBoard</button>
      </div>
      <div className="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0 position-relative">
        <span className="fa fa-search form-control-feedback main-search-icon"></span>
        <input type="search" className="form-control main-search" placeholder="Search" aria-label="Search"/>
      </div>
      <div className="col-md-3 d-flex justify-content-between ">
        <DarkMode/>
        {/* <button type="button" className="btn btn-link me-2" onClick={logOutHandler}>Logout</button> */}
        <div className="dropdown-center d-flex ">

<i className="bi bi-person-circle"></i>



<button className="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">

Benjamin <i className="bi bi-chevron-down"></i>



</button>

<ul className="dropdown-menu">

  <li><a className="dropdown-item" href="#" onClick={logOutHandler}><i className="bi bi-box-arrow-right"></i> Logout</a></li>



</ul>

</div>
      </div>
    </header>
  )
}

export default Header
