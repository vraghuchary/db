import React from 'react'
import './DarkMode.css';

function DarkMode() {
    const setDarkMode = () => {
        document.querySelector("body").setAttribute("data-theme", "dark") 
        localStorage.setItem("selectedTheme", "dark")
    }
    const setLightMode = () => {
        document.querySelector("body").setAttribute("data-theme", "light") 
        localStorage.setItem("selectedTheme", "light")
    }
    //setDarkMode();
    const toggleTheme = (e) => {
        if (e.target.checked) setDarkMode(); 
        else setLightMode();
    }

    const sTheme = localStorage.getItem("selectedTheme");

    if(sTheme === "dark") {
        setDarkMode();
    }

  return (
    <div className="d-flex align-items-center form-switch mx-5 ">
        {/* <input className="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" defaultChecked = {sTheme === "dark"} onChange={toggleTheme}/>
        <div className='background'></div> */}
          <input type="checkbox" className="checkbox" id="dMode" defaultChecked = {sTheme === "dark"} onChange={toggleTheme}/>
          <label for="dMode" className="checkbox-label">
          <i className="bi bi-moon"></i>
          <i className="bi bi-brightness-high"></i>

          <span className="ball"></span>
        </label>
    </div>
  )
}

export default DarkMode
