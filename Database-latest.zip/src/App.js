import { BrowserRouter as Router, Route, Routes, Outlet  } from 'react-router-dom';
import './App.css';
import LoginForm from './components/LoginForm/LoginForm';
import Main from './components/Main/Main';


function App() {
  return (
    <>
      <Router>
        <Routes>
          <Route exact path="/" element={<LoginForm/>} />
          {/* <PrivateRoute path="/main" component={Main} /> */}
          <Route path="/main" element={<Main/>} />
        </Routes>
      </Router>
      <Outlet/>
    </>
  );
}

export default App;
