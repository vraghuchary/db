export const explorer = {
    name: "Postgres@196.263.180.216",
    isFolder: true,
    items: [
      {
        name: "dev_jrnydb_0313",
        isFolder: true,
        items: [
          {
            name: "Information_schema",
            isFolder: false
          },{
            name: "pg_catalog",
            isFolder: false
          },{
            name: "Public",
            isFolder: true,
            items:[
                {
                    name:"base_radio_link_v1",
                    isFolder: false
                }
            ]
          }
        ]
      }
    ]
  };
  