import React, { useRef, useEffect } from 'react';

const CustomDonutGraph = ({ data, colors, width, height }) => {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(canvas.width, canvas.height) / 2;

    let startAngle = -Math.PI / 2;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Calculate total value
    const total = data.reduce((acc, val) => acc + val, 0);

    // Draw each segment
    data.forEach((value, i) => {
      const sliceAngle = (2 * Math.PI * value) / total;
      const endAngle = startAngle + sliceAngle;

      // Draw segment
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, startAngle, endAngle);
      ctx.lineTo(centerX, centerY);
      ctx.fillStyle = colors[i];
      ctx.fill();

      // Update start angle for next segment
      startAngle = endAngle;
    });

    // Draw inner circle
    const innerRadius = radius * 0.6;
    ctx.beginPath();
    ctx.arc(centerX, centerY, innerRadius, 0, 2 * Math.PI);
    ctx.fillStyle = 'white';
    ctx.fill();
  }, [data, colors]);

  return <canvas className="" ref={canvasRef} width={width} height={height} />;
};

export default CustomDonutGraph;
