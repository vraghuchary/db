import { useState } from 'react'
import './SideBar.css'
import Folder from '../Folder/Folder.js'
import {explorer} from '../../data/FolderData.js'
import DataSourcesModal from '../DataSourcesModal/DataSourcesModal.js'

const dbArr = ["PostgreSQL", "PostgreSQL via CloudSQL Proxy", "Amazon Aurora MySql", "Amazon Redshift", "Apache Cassandra", "Apache Derby", "Apache Hive", "Azure SQL Database", "Azure Synapse Analytics", "BigQuery"]

const SideBar = (props) => {    
    const [searchValue, setSearchValue] = useState("");

    return(
        <>
            <div className="sideBar">
                <p className="db-head">Database Explorer</p>
                <div className="dropdown">
                    <button className="btn btn-light dropdown-toggle db-add" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        +
                    </button>
                    <div className="dropdown-menu">
                        <div className="form-group has-search">
                            <span className="fa fa-search form-control-feedback"></span>
                            <input type="text" value={searchValue} className="form-control" onChange={(e) => setSearchValue(e.target.value)} placeholder="To a Server"/>
                        </div>
                        <ul>
                            {dbArr.filter((name) => name.match(new RegExp(searchValue, "i")))
                            .map((name) => {
                                return <li key={name}><a className="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">{name}</a></li>;
                            })}
                        </ul>
                    </div>
                </div>
                {(props.folderStr !== 'dashboard') ? <Folder explorer={explorer}/> : <></>}
                <DataSourcesModal/>
            </div>
        </>
    )
}

export default SideBar