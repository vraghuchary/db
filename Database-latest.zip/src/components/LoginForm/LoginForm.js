import React, { useState } from 'react'
import { useNavigate  } from 'react-router-dom'
import logo from '../assets/images/logo.png'
// import Header from '../Header/Header'
import './LoginForm.css'

const LoginForm = () => {
  const [userName, setUserName] = useState('');
  const [password, setpassword] = useState('');
  //const [loggedIn, setLoggedIn] = useState(false);
  const [error, setError] = useState('');
  const history = useNavigate ();

  const successObj = { userName: "test", password: "test" }; // for testing purposes only

  // const handleSubmit = async(e) => {

  //   e.preventDefault();
  //   try {
  //     const response = await fetch('YOUR_API_ENDPOINT', {
  //       method: 'POST',
  //       headers: {
  //         'Content-Type': 'application/json'
  //       },
  //       body: JSON.stringify({ userName, password })
  //     });

  //     if (!response.ok) {
  //       throw new Error('Invalid credentials');
  //     }
  //        setLoggedIn(true);
  //     // Handle successful login, e.g., redirect to dashboard
  //   } catch (error) {
  //     setError(error.message);
  //     setLoggedIn(false);
  //   }

  // }


  // for testing purposes only **** Start ****
  const handleSubmit = (e) => {
    e.preventDefault();
    if (userName === successObj.userName && password === successObj.password) {
      //window.location.href = "/dashboard";
      history('/main');
     // setLoggedIn(true);
    } else {
     // setLoggedIn(false);
      setError('Login Failed');
    }
  };
  // for testing purposes only **** End ****

  return (
    <>
    <div className="container login">
      <div className="row justify-content-center vertical-center">
        <div className="col-lg-4 col-md-6 col-sm-6">
          <div className="card shadow p-4 login">
            <div className="card-title text-center">
              <h1 className="">
              <img src={logo} alt="database"/>
              </h1>
            
            </div>
            <div className="card-body">
              
              <form onSubmit={(e)=>handleSubmit(e)}>
                <div className="mb-4">
                  <label htmlFor="username" className="form-label text">Username/Email</label>
                  <input type="text" className="form-control" id="username" value={userName} onChange={(e) => setUserName(e.target.value)}/>
                </div>
                <div className="mb-4">
                  <label htmlFor="password" className="form-label text">Password</label>
                  <input type="password" className="form-control" id="password" value={password} onChange={(e) => setpassword(e.target.value)}/>
                </div>
                {/* <div className="mb-4">
                  <input type="checkbox" className="form-check-input" id="remember" />
                  <label htmlFor="remember" className="form-label">Remember Me</label>
                </div> */}
                <div className="d-grid">
                  <button type="submit" className="btn text-light main-bg">Login</button>
                </div>
              </form> 
              {error && <p className="error mt-2">{error}</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  </>
  )
}

export default LoginForm