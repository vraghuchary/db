import './Tooltip.css'
import 'bootstrap-icons/font/bootstrap-icons.css';

const TooltipBts = (props) => {
    return(
        <>
            <div className="tooltipDrp dropdown">
                    <button className="btn dropdown-toggle db-add" type="button" data-bs-toggle="dropdown" aria-expanded="false" disabled={props.fltChkDisabled}>
                    <i className="bi bi-three-dots-vertical db-menu-dots"></i>

                    </button>
                    <div className="dropdown-menu" aria-labelledby="dropdownMenuLink">
                        <button className="dropdown-item">Aliquam porta lorem</button>
                        <button className="dropdown-item">Ut quis magna acu justo.</button>
                        <button className="dropdown-item">In vitae diam non</button>
                    </div>
                </div>
        </>
    )
}

export default  TooltipBts;