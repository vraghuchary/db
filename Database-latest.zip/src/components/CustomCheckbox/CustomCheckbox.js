import { useState } from 'react';
import './CustomCheckbox.css'

const CustomCheckbox = (props) => {
    const [checked, setChecked] = useState('unchecked')
    const handleChange = (e) => {
        const { checked } = e.target;
        if(checked){
            setChecked('checked')
            props.sendDataToParent('checked')
        }else{
            setChecked('unchecked')
            props.sendDataToParent('unchecked')
        }
    }
    return(
        <>
            <div className="custom-check form-check">
                <input className="form-check-input me-1" type="checkbox" onChange={(e) => handleChange(e)} name={props.name} value={props.value} id={"flexCheckDefault" + props.name} disabled={props.fltChkDisabled}/>
                <label className="form-check-label" htmlFor="flexCheckDefault">
                    Column 33
                </label>
            </div>
        </>
    )
}

export default CustomCheckbox