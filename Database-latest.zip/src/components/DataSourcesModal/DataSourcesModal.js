import React, { useRef, useState, useEffect} from 'react'
import './DataSourcesModal.css'
import {useMyContext} from '../Main/Main'
import CheckboxTree from 'react-checkbox-tree';
import { fileSystem as nodes } from '../../data/Common';

function DataSourcesModal() {
  //{host:"", port: "", authentication:"", user: "", password:"", save:"", database:"", url:""};
  const intialValues = {host:"", port: "", user: "", password:"", database:"", url:""};
  const [formValues, setFormValues] = useState(intialValues);
  //const [formValid, setFormValid] = useState(false);
  const [tabDisabled, setTabDisabled] = useState('disabled')
  const [alertDisabled, setAlertDisabled] = useState('d-none')

  const [show, setShow] = useState(true)
  const tabBtnRef = useRef(null);
  const tabBackBtnRef = useRef(null);
  const { value, updateValue } = useMyContext();
  const [checked, setChecked] = useState([
    '/app/Http/Controllers/WelcomeController.js',
    '/app/Http/routes.js',
    '/public/assets/style.css',
    '/public/index.html',
    '/.gitignore',
  ]);
  const [expanded, setExpanded] = useState(['/app']);

  const onCheck = (value) => {
      setChecked(value);
  };

  const onExpand = (value) => {
      setExpanded(value);
  };

  const tabClickHandler = () =>{
    if (tabBtnRef.current && show) {
      tabBtnRef.current.click()
      setShow(false)
    }else if(tabBackBtnRef.current && !show){
      tabBackBtnRef.current.click()
      setShow(true)
    }
  }

  const srtAnalysisClkHandler = () =>{
    updateValue('Analysis');
    setShow(true)
    tabBackBtnRef.current.click()
  }

  const handleChange = (e) =>{
    const{name , value} = e.target;
    setFormValues({...formValues, [name]: value});
  }

  const checkFormValidity = () => {
    const {host, port, user, password, database, url} = formValues;
    return host.trim() !== '' && port.trim() !== '' && user.trim() !== '' && password.trim() !== '' && database.trim() !== '' && url.trim() !== '';
  };

  useEffect(() => {
    //setFormValid(checkFormValidity());
    let formValidity = checkFormValidity()
    if(formValidity){
      setTabDisabled('')
    }else{
      setTabDisabled('disabled')
    }
  }, [formValues]);

  const handleSubmit =(e) =>{
    e.preventDefault();
      tabClickHandler()
  }

  const handleTestbtn = () => {
    setAlertDisabled('');
    setTimeout(() => {
      setAlertDisabled('d-none');
    }, 5000);
  }

  return (
    <>
{/* <button type="button" className="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
  +
</button> */}


<div className="modal fade" id="exampleModal" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div className="modal-dialog modal-lg">
    <div className="modal-content">
      <div className="modal-header">
        <h2 className="modal-title" id="exampleModalLabel">PostgreSQL - Connection Details</h2>
      </div>
      <div className="modal-body">
       
      <form onSubmit={handleSubmit} autoComplete='off'>
        <div className="form-group row mb-3">
          <label htmlFor="name" className="col-sm-2 col-form-label">Name</label>
          <div className="col-sm-10">
            <input type="text" className="form-control" id="name" />
          </div>
        </div>
        <div className="form-group row">
          <label htmlFor="location" className="col-sm-2 col-form-label">Location</label>
          <div className="col-sm-10">
            <input type="text" className="form-control" id="location"/>
          </div>
        </div>


        <ul className="nav nav-underline mt-3">
          <li className="nav-item">
            <a className="nav-link active" ref={tabBackBtnRef} data-bs-toggle="tab" href="#generalTab">General</a>
          </li>
          <li className="nav-item">
            <a className={"nav-link " + tabDisabled} ref={tabBtnRef} data-bs-toggle="tab" href="#schemasTab">Schemas</a>
          </li>
        </ul>


        <div className="tab-content">
          <div className="tab-pane active" id="generalTab">
            <div>
              <div className="row g-3 mt-2">
                <div className="col-md-6">
                  <label htmlFor="inputEmail4" className="form-label">Host</label>
                  <input type="text" className="form-control" id="inputEmail4" name='host' value={formValues.host} onChange={handleChange}/>
                </div>
                <div className="col-md-6">
                  <label htmlFor="inputPassword4" className="form-label">Port</label>
                  <input type="text" className="form-control" id="inputPassword4" name='port' value={formValues.port} onChange={handleChange}/>
                </div>
            
                <div className="col-md-6">
                  <label htmlFor="user" className="form-label">User</label>
                  <input type="text" className="form-control" id="user" name='user' value={formValues.user} onChange={handleChange}/>
                </div>
                <div className="col-md-6">
                  <label htmlFor="inputCity" className="form-label">Password</label>
                  <input type="password" className="form-control" id="inputCity" name='password' value={formValues.password}  onChange={handleChange}/>
                </div>
          
                <div className="col-6">
                  <label htmlFor="db" className="form-label">Database</label>
                  <input type="text" className="form-control" id="db" name='database' value={formValues.database} onChange={handleChange}/>
                </div>
                <div className="col-6">
                  <label htmlFor="url" className="form-label">URL</label>
                  <input type="text" className="form-control" id="url" name='url' value={formValues.url} onChange={handleChange} />
                </div>
              </div>
            </div>
            <div className="justify-content-between modal-footer px-0">
                <button type="button" className="btn btn-outline-primary py-1 px-3" onClick={handleTestbtn}>Test Connection </button>
                {/* <button type="button" className="btn btn-outline-secondary py-1 px-3" onClick={tabClickHandler}>Next</button> */}
                <div className={" connection-alert " + alertDisabled} role="alert">
                <i className="bi bi-check-circle"></i> Test Connection is successfull 
                </div>
               <div> <button type="button" className="btn btn-outline-secondary py-1 px-3 me-2" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" className="btn btn-outline-secondary py-1 px-3">Next</button>
                </div>
            </div>
          </div>
          <div className="tab-pane fade" id="schemasTab">
            <div className="pt-2 pb-2">
            <CheckboxTree
                checked={checked}
                expanded={expanded}
                nodes={nodes}
                onCheck={onCheck}
                onExpand={onExpand}
              
            />
            </div>
            <div className="form-group row mb-3 __web-inspector-hide-shortcut__"><label htmlFor="name" className="col-sm-3 col-form-label">Schema pattern</label><div className="col-sm-9"><input type="text" className="form-control" id="name"/></div></div>
            <div className="form-group row mb-3 __web-inspector-hide-shortcut__"><label htmlFor="name" className="col-sm-3 col-form-label">Object filter</label><div className="col-sm-9"><input type="text" className="form-control" id="name"/></div></div>
            <div className="form-check">
              <input className="form-check-input" type="checkbox" value="" id="flexCheckDefault"/>
              <label className="form-check-label" htmlFor="flexCheckDefault">
              Show internal system schemas
              </label>
            </div>
            <div className="form-check">
              <input className="form-check-input" type="checkbox" value="" id="flexCheckChecked" />
              <label className="form-check-label" htmlFor="flexCheckChecked">
              Show template databases
              </label>
            </div>
           
            <div className="modal-footer">
                <button type="button" className="btn btn-outline-secondary py-1 px-3" onClick={tabClickHandler}>Back</button>
                <button type="button" className="btn btn-primary py-1 px-3" data-context-value={value} data-bs-dismiss="modal" onClick={srtAnalysisClkHandler}>Start Analysis</button>
            </div>
          </div>
        </div>
      </form>
      
      </div>
    </div>
  </div>
</div>
    </>
  )
}

export default DataSourcesModal
