import CustomDonutGraph from '../CustomDonutGraph/CustomDonutGraph'
import dbList from '../assets/images/db-list.png'
import tableIcon from '../assets/images/tables-icon.png'
import infoIcon from '../assets/images/info-icon.png'
import'./DashBoard.css'
import GoogleMapComponent from '../GoogleMapComponent/GoogleMapComponent'

const DashBoard = () => {
    return(
        <>
            <div className="col-12">
             <p className="mt-3 text">Hi Benjamin!</p>
            </div>
            <div className="row mt-3">
              <div className="col-md-4">
                <div className='card p-3'>
                <div className="row g-0">
                      <div className="col-md-4 d-flex align-items-center ">
                        <CustomDonutGraph data={[40, 60]} colors={['#FFCDCD', '#EB5757']} width={86} height={86}/>
                      </div>
                      <div className="col-md-8">
                        <div className="card-body ps-0">
                          <p className="card-title text heading-2">Number of Columns</p>
                          <p className="card-text db-val num-columns-1">120</p>
                        </div>
                      </div>
                    </div>
                </div>
              </div>
              <div className="col-md-4">
                <div className='card p-3'>
                <div className="row g-0">
                      <div className="col-md-4 d-flex align-items-center ">
                        <CustomDonutGraph data={[70, 30]} colors={['#CFEFE9', '#0ABD9E']} width={86} height={86}/>
                      </div>
                      <div className="col-md-8">
                        <div className="card-body ps-0">
                          <p className="card-title text heading-2">Number of Columns</p>
                          <p className="card-text db-val num-columns-2">100</p>
                        </div>
                      </div>
                    </div>  
                </div>
              </div>
              <div className="col-md-4">
          
              <div className='card p-3'>
                <div className="row g-0">
                      <div className="col-md-4 d-flex align-items-center p-0">
                        <CustomDonutGraph data={[20, 55, 25]} colors={['#E7E7E7', '#EB5757', '#0ABD9E']} width={86} height={86}/>
                      </div>
                      <div className="col-md-8">
                        <div className="card-body ps-0">
                          <p className="card-title text heading-2">Total Columns {220}</p>
                          <div className="custom-check form-check me-3">
                              <input className="form-check-input me-1" type="radio" name='green-red-chk' value='green' id="flexCheckDefault-green-chk"/>
                              <label className="form-check-label text" htmlFor="flexCheckDefault-green-chk">
                                  100
                              </label>
                          </div>
                          <div className="custom-check form-check">
                              <input className="form-check-input me-1" type="radio" name='green-red-chk' value='red' id="flexCheckDefault-red-chk"/>
                              <label className="form-check-label text" htmlFor="flexCheckDefault-red-chk">
                                  120
                              </label>
                          </div>
                        </div>
                      </div>
                    </div>  
                </div>
              
              </div>
            </div>
            <div className="row">
              <div className="col-4">
                <div className="row">
                  <div className="col-12 mt-5">
                    <div className='card p-3'>
                    <div className="row g-0">
                      <div className="col-md-3 d-flex align-items-center justify-content-center ">
                      <span className="icon-holder"><img src={dbList} alt="database"/></span>  
                      </div>
                      <div className="col-md-9">
                        <div className="card-body">
                          <p className="card-title text heading-2">List of Databases</p>
                          <p className="card-text db-val list-dt">26</p>
                        </div>
                      </div>
                    </div>
                    </div>
                  </div>
                  <div className="col-12 mt-4">
                    <div className='card p-3'>
                    <div className="row g-0">
                    <div className="col-md-3 d-flex align-items-center justify-content-center ">
                      <span className="icon-holder"><img src={tableIcon} alt="database"/></span>  
                      </div>
                      <div className="col-md-9">
                        <div className="card-body">
                          <p className="card-title text heading-2">Number of tables</p>
                          <p className="card-text db-val number-of-tables">120</p>
                        </div>
                      </div>
                    </div>
                    </div>
                  </div>
                  <div className="col-12 mt-4 pb-5">
                    <div className='card p-3'>
                    <div className="row g-0">
                    <div className="col-md-3 d-flex align-items-center justify-content-center ">
                      <span className="icon-holder"><img src={infoIcon} alt="database"/></span>  
                      </div>
                      <div className="col-md-9">
                        <div className="card-body">
                          <p className="card-title text heading-2">Information schema</p>
                          <p className="card-text db-val info-schema">140</p>
                        </div>
                      </div>
                    </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='col-8 pt-4 px-3 max-500 d-flex flex-column'>
                <div className='text-end map-icons'><a href="#" className='me-3'><i className="bi bi-download"></i></a> <a href="#"><i className="bi bi-arrow-clockwise"></i></a></div>
                <GoogleMapComponent/>
              </div>
            </div>
        </>
    )
}

export default DashBoard