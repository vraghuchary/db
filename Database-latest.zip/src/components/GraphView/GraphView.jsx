import CustomDonutGraph from "../CustomDonutGraph/CustomDonutGraph"

const GraphView = (props) => {
    return (
        <>
            <div className="align-content-start mt-3 row vh-100 ">
                <div className="col-md-4">
                    <div className='card p-3'>
                        <div className="row g-0">
                            <div className="col-md-4 d-flex align-items-center ">
                            <CustomDonutGraph data={props.data.grpData1} colors={props.color.grpColor1} width={86} height={86} />
                            </div>
                            <div className="col-md-8">
                                <div className="card-body p-0">
                                    <p className="card-title text heading-2">Table Name 01</p>
                                    <p className="card-title text">Number of columns 116</p>
                                    <div className="custom-check form-check me-3">
                                        <input className="form-check-input me-1" type="radio" name='green-red-chk' value='green' id="flexCheckDefault-green-chk" />
                                        <label className="form-check-label text" htmlFor="flexCheckDefault-green-chk">
                                            30
                                        </label>
                                    </div>
                                    <div className="custom-check form-check">
                                        <input className="form-check-input me-1" type="radio" name='green-red-chk' value='red' id="flexCheckDefault-red-chk" />
                                        <label className="form-check-label text" htmlFor="flexCheckDefault-red-chk">
                                            70
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className='card p-3'>
                        <div className="row g-0">
                            <div className="col-md-4 d-flex align-items-center ">
                            <CustomDonutGraph data={props.data.grpData2} colors={props.color.grpColor2} width={86} height={86} />
                            </div>
                            <div className="col-md-8">
                                <div className="card-body p-0">
                                    <p className="card-title text heading-2">Table Name 02</p>
                                    <p className="card-title text">Number of columns 200</p>
                                    <div className="custom-check form-check me-3">
                                        <input className="form-check-input me-1" type="radio" name='green-red-chk' value='green' id="flexCheckDefault-green-chk" />
                                        <label className="form-check-label text" htmlFor="flexCheckDefault-green-chk">
                                            90
                                        </label>
                                    </div>
                                    <div className="custom-check form-check">
                                        <input className="form-check-input me-1" type="radio" name='green-red-chk' value='red' id="flexCheckDefault-red-chk" />
                                        <label className="form-check-label text" htmlFor="flexCheckDefault-red-chk">
                                            110
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className='card p-3'>
                        <div className="row g-0">
                            <div className="col-md-4 d-flex align-items-center p-0">
                                <CustomDonutGraph data={props.data.grpData3} colors={props.color.grpColor3} width={86} height={86} />
                            </div>
                            <div className="col-md-8">
                                <div className="card-body p-0">
                                    <p className="card-title text heading-2">Table Name 03</p>
                                    <p className="card-title text">Number of columns 160</p>
                                    <div className="custom-check form-check me-3">
                                        <input className="form-check-input me-1" type="radio" name='green-red-chk' value='green' id="flexCheckDefault-green-chk" />
                                        <label className="form-check-label text" htmlFor="flexCheckDefault-green-chk">
                                            40
                                        </label>
                                    </div>
                                    <div className="custom-check form-check">
                                        <input className="form-check-input me-1" type="radio" name='green-red-chk' value='red' id="flexCheckDefault-red-chk" />
                                        <label className="form-check-label text" htmlFor="flexCheckDefault-red-chk">
                                            90
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className='card p-3 mt-3'>
                        <div className="row g-0">
                            <div className="col-md-4 d-flex align-items-center p-0">
                                <CustomDonutGraph data={props.data.grpData4} colors={props.color.grpColor4} width={86} height={86} />
                            </div>
                            <div className="col-md-8">
                                <div className="card-body p-0">
                                    <p className="card-title text heading-2">Table Name 04</p>
                                    <p className="card-title text">Number of columns 140</p>
                                    <div className="custom-check form-check me-3">
                                        <input className="form-check-input me-1" type="radio" name='green-red-chk' value='green' id="flexCheckDefault-green-chk" />
                                        <label className="form-check-label text" htmlFor="flexCheckDefault-green-chk">
                                            20
                                        </label>
                                    </div>
                                    <div className="custom-check form-check">
                                        <input className="form-check-input me-1" type="radio" name='green-red-chk' value='red' id="flexCheckDefault-red-chk" />
                                        <label className="form-check-label text" htmlFor="flexCheckDefault-red-chk">
                                            80
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className='card p-3 mt-3'>
                        <div className="row g-0">
                            <div className="col-md-4 d-flex align-items-center p-0">
                                <CustomDonutGraph data={props.data.grpData5} colors={props.color.grpColor5} width={86} height={86} />
                            </div>
                            <div className="col-md-8">
                                <div className="card-body p-0">
                                    <p className="card-title text heading-2">Table Name 05</p>
                                    <p className="card-title text">Number of columns 224</p>
                                    <div className="custom-check form-check me-3">
                                        <input className="form-check-input me-1" type="radio" name='green-red-chk' value='green' id="flexCheckDefault-green-chk" />
                                        <label className="form-check-label text" htmlFor="flexCheckDefault-green-chk">
                                            80
                                        </label>
                                    </div>
                                    <div className="custom-check form-check">
                                        <input className="form-check-input me-1" type="radio" name='green-red-chk' value='red' id="flexCheckDefault-red-chk" />
                                        <label className="form-check-label text" htmlFor="flexCheckDefault-red-chk">
                                            144
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </>
    )
}

export default GraphView