import React, { createContext, useContext, useState } from 'react'
import Header from '../Header/Header'
import SideBar from '../SideBar/SideBar'
import './Main.css'
import DashBoard from '../DashBoard/DashBoard'
import Analysis from '../Analysis/Analysis'

const setAnalysisVal = createContext();

function Main() {

  const [value, setValue] = useState('dashboard');
  const [btnTextChange, setBtnTextChange] = useState(true)
  const [filterChkdisabled, setFilterChkdisabled] = useState(false)

  const updateValue = newValue => {
    setValue(newValue);
  };

  const modalBtnClick = () => {
    setBtnTextChange(false)
    setFilterChkdisabled(true)
  }

  const editBtnHandler = () => {
    setBtnTextChange(true)
    setFilterChkdisabled(false)
  }

  return (
    <setAnalysisVal.Provider value={{ value, updateValue }}>
      <div className="container">
      <Header/>
        <div className="row">
            <div className="col-md-2 p-0">
              <div className="left-sec">
                <SideBar folderStr={value}/>
              </div>
            </div>
            <div className='col-md-10 right-sec'>
              {(value === 'dashboard' || value === 'dashboardAnalysis')  ?
              <DashBoard/>
              :
              <>
                <Analysis fltChkDisabled={filterChkdisabled}/>
                <div className='row  px-0 mt-3'>
                  <div className="col-12 text-end  mb-4 footer-btn">
                  <button type="button" className="btn btn-outline-secondary py-1 px-3 me-2">Cancel</button>
                    {btnTextChange ? <button type="button" className="btn btn-primary py-1 px-3" data-bs-toggle="modal" data-bs-target="#successModal">
                      Approve
                    </button>
                    :
                    <button type="button" className="btn btn-primary py-1 px-3" onClick={editBtnHandler}>
                      Edit
                    </button>}
                  </div>
          
                  
                </div>

                <div className="modal fade" id="successModal" tabIndex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
                  <div className="modal-dialog">
                    <div className="modal-content p-5">
                      <div className="modal-body text-center pb-0">
                        <p className="mb-0" >Your update was applied successfully</p>
                      </div>
                      <div className="justify-content-center modal-footer">
                        <button type="button" className="btn btn-primary px-4" onClick={modalBtnClick}  data-bs-dismiss="modal">Ok</button>
                      </div>
                    </div>
                  </div>
                </div>
              </>
              }
            </div> 
        </div>
        
      </div>
    </setAnalysisVal.Provider>
  )
}

export default Main

export const useMyContext = () => {
  return useContext(setAnalysisVal);
};
