import { useState } from 'react'
import './Analysis.css'
import AnalysisCheckBox from './AnalysisCheckBox/AnalysisCheckbox'
import GraphView from '../GraphView/GraphView'

const Analysis = (props) => {
  const colorDataSet = {grpColor1:['#38383a', '#EB5757', '#0ABD9E'], grpColor2:['#38383a', '#EB5757', '#0ABD9E'], grpColor3:['#38383a', '#EB5757', '#0ABD9E'], grpColor4:['#38383a', '#EB5757', '#0ABD9E'], grpColor5:['#38383a', '#EB5757', '#0ABD9E']}
  const dataSet = {grpData1:[20, 55, 25], grpData2:[20, 55, 25],grpData3:[20, 55, 25], grpData4:[20, 55, 25],grpData5:[20, 55, 25]}
  const n = 18
  const [greenCheckboxShow, setGreenCheckboxShow] = useState('')
  const [redCheckboxShow, setRedCheckboxShow] = useState('')
  const [graphTbView, setGraphTbView] = useState(false)
  const [graphDataSet, setGraphDataSet] = useState(dataSet)
  const [graphColorDataSet, setGraphColorDataSet] = useState(colorDataSet)

  const modifiedDataSet = (data, index) => {
    for(let x in data){
      data[x].splice(index, 1)
    }
    return data
  }

  const redCheckboxHandler = (e) =>{
    let newDataSet = dataSet;
    let newColorData = colorDataSet
    if(e.target.checked){
      setGreenCheckboxShow('')
      setRedCheckboxShow('redChk')
      setGraphColorDataSet(modifiedDataSet(newColorData, 2))
      setGraphDataSet(modifiedDataSet(newDataSet, 2))
    }else{
      setGreenCheckboxShow('')
      setRedCheckboxShow('')
      setGraphColorDataSet(colorDataSet)
      setGraphDataSet(dataSet)
    }
  }

  const greenCheckboxHandler = (e) =>{
    let newDataSet = dataSet;
    let newColorData = colorDataSet
    if(e.target.checked){
      setGreenCheckboxShow('greenChk')
      setRedCheckboxShow('')
      setGraphColorDataSet(modifiedDataSet(newColorData, 1))
      setGraphDataSet(modifiedDataSet(newDataSet, 1))
    }else{
      setGreenCheckboxShow('')
      setRedCheckboxShow('')
      setGraphColorDataSet(colorDataSet)
      setGraphDataSet(dataSet)
    }
  }

  const redGreenCheckboxHandler = (e) => {
    if(e.target.checked){
      setGreenCheckboxShow('')
      setRedCheckboxShow('')
      setGraphColorDataSet(colorDataSet)
      setGraphDataSet(dataSet)
    }
  }

  const graphTableView = (viewBoolean) => {
    if(graphTbView){
      setGraphTbView(viewBoolean)
    }else{
      setGraphTbView(viewBoolean)
    }
  }
    return(
        <>  
        <div className="db-breadcrumb">postgres@196.263.180.216 \  dev_jrnydb_0313   \  information_schema \  pg_catalog \  public \ PostgreSQL</div>           
         <div className="analysis-filter d-flex justify-content-between">
         <div>
              <span className="me-2 mb-0">Filter by</span>
             
                <div className="custom-check form-check">
                    <input className="form-check-input me-1" type="radio" onChange={greenCheckboxHandler} name='green-red-chk' value='green' id="flexCheckDefault-green-chk" disabled={props.fltChkDisabled}/>
                </div>
                <div className="custom-check form-check">
                    <input className="form-check-input me-1" type="radio" onChange={redCheckboxHandler} name='green-red-chk' value='red' id="flexCheckDefault-red-chk" disabled={props.fltChkDisabled}/>
                </div>
                <div className="custom-check form-check">
                    <input className="form-check-input me-1" type="radio" onChange={redGreenCheckboxHandler} name='green-red-chk' value='both' id="flexCheckDefault-green-red-chk" disabled={props.fltChkDisabled}/>
                </div>
              </div>
             <div>
              <button className = {"btn btn-outline-primary rounded-0 " + (graphTbView ? '':'active')} onClick={() => graphTableView(false)}><i className="bi bi-table"></i></button>
              <button className = {"btn btn-outline-primary rounded-0 " + (graphTbView ? 'active':'')}  onClick={() => graphTableView(true)}><i className="bi bi-pie-chart-fill"></i></button>
             
        
             
             
             </div>
             

            </div>
            { graphTbView ? 
              <GraphView data = {graphDataSet} color = {graphColorDataSet}/>
              : 
              <>
                <h2 className="mt-4">Table Name 01</h2>
        
                <div className="row g-1">
                    {
                      [...Array(n)].map((e, i) => <AnalysisCheckBox keyProp={i} name={i} value= "Column 33" greenChkClass={greenCheckboxShow} redChkClass={redCheckboxShow} fltChkDisabled={props.fltChkDisabled}/> )
                    }
                </div>

                <h2 className="mt-5">Table Name 02</h2>

                <div className="row g-1">
                    {
                      [...Array(n)].map((e, i) => <AnalysisCheckBox keyProp={i} name={i} value= "Column 33" greenChkClass={greenCheckboxShow} redChkClass={redCheckboxShow} fltChkDisabled={props.fltChkDisabled}/>)
                    }
                </div>
                <h2 className="mt-5">Table Name 03</h2>
            
                <div className="row g-1">
                    {
                      [...Array(n)].map((e, i) => <AnalysisCheckBox keyProp={i} name={i} value= "Column 33" greenChkClass={greenCheckboxShow} redChkClass={redCheckboxShow} fltChkDisabled={props.fltChkDisabled}/>)
                    }
                </div>
              </>
            }
           
        </>
    )
}

export default Analysis